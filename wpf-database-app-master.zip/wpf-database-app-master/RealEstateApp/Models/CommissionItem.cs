﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealEstateApp {

    public class CommissionItem {

        public Decimal Amount { get; set; }
        public String Reason { get; set; }
        public DateTime Date { get; set; }
    }
}
