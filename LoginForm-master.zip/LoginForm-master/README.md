LoginForm
=========

Login and Registration form in WPF

Login Form:

![alt tag](http://img443.imageshack.us/img443/5526/r1yo.png)

Registration:

![alt tag](http://img209.imageshack.us/img209/195/78i8.png)
